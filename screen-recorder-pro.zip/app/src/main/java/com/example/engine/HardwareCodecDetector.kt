package com.example.engine

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build

data class CodecCapability(
    val name: String,
    val mimeType: String,
    val isHardwareAccelerated: Boolean,
    val isEncoder: Boolean,
    val maxWidth: Int,
    val maxHeight: Int,
    val maxBitrateMbps: Int,
    val maxFps: Int,
    val vendor: String
)

object HardwareCodecDetector {

    fun getSupportedEncoders(): List<CodecCapability> {
        val list = mutableListOf<CodecCapability>()
        try {
            val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            for (info in codecList.codecInfos) {
                if (!info.isEncoder) continue

                val targetMimes = listOf("video/avc", "video/hevc")
                for (mime in targetMimes) {
                    if (info.supportedTypes.contains(mime)) {
                        try {
                            val caps = info.getCapabilitiesForType(mime)
                            val videoCaps = caps.videoCapabilities

                            val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                info.isHardwareAccelerated
                            } else {
                                !info.name.startsWith("OMX.google.") && !info.name.startsWith("c2.android.")
                            }

                            val vendor = when {
                                info.name.contains("qcom", ignoreCase = true) -> "Qualcomm Adreno / Hexagon"
                                info.name.contains("exynos", ignoreCase = true) || info.name.contains("samsung", ignoreCase = true) -> "Samsung Exynos"
                                info.name.contains("kirin", ignoreCase = true) || info.name.contains("hisi", ignoreCase = true) -> "HiSilicon Kirin"
                                info.name.contains("mtk", ignoreCase = true) || info.name.contains("mediatek", ignoreCase = true) -> "MediaTek Helio/Dimensity"
                                info.name.contains("google", ignoreCase = true) || info.name.contains("tensor", ignoreCase = true) -> "Google Tensor / Software"
                                info.name.contains("nvidia", ignoreCase = true) -> "NVIDIA Tegra"
                                else -> "Hardware Vendor Engine"
                            }

                            val maxWidth = videoCaps?.supportedWidths?.upper ?: 3840
                            val maxHeight = videoCaps?.supportedHeights?.upper ?: 2160
                            val maxBitrate = ((videoCaps?.bitrateRange?.upper ?: 100_000_000) / 1_000_000)
                            val maxFps = (videoCaps?.supportedFrameRates?.upper ?: 60).toInt()

                            list.add(
                                CodecCapability(
                                    name = info.name,
                                    mimeType = mime,
                                    isHardwareAccelerated = isHw,
                                    isEncoder = true,
                                    maxWidth = maxWidth,
                                    maxHeight = maxHeight,
                                    maxBitrateMbps = maxBitrate,
                                    maxFps = maxFps,
                                    vendor = vendor
                                )
                            )
                        } catch (_: Exception) { }
                    }
                }
            }
        } catch (_: Exception) { }
        return list
    }

    fun is4kSupported(mimeType: String): Boolean {
        return getSupportedEncoders().any {
            it.mimeType == mimeType && it.maxWidth >= 3840 && it.maxHeight >= 2160
        }
    }

    fun isHevcSupported(): Boolean {
        return getSupportedEncoders().any { it.mimeType == "video/hevc" && it.isHardwareAccelerated }
    }
}
