package com.example.engine

import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import com.example.data.AudioSourceMode
import com.example.data.RecorderSettings
import com.example.data.VideoCodec
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class MediaCodecRecorder(
    private val settings: RecorderSettings,
    private val width: Int,
    private val height: Int,
    private val densityDpi: Int,
    private val mediaProjection: MediaProjection,
    private val outputFile: File,
    private val onProgress: (durationMs: Long, bytesEncoded: Long, fps: Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private val TAG = "MediaCodecRecorder"

    private var videoEncoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null

    private var audioEncoder: MediaCodec? = null
    private var audioMixer: DualAudioMixerEngine? = null

    private var mediaMuxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    private val isMuxerStarted = AtomicBoolean(false)

    private val isRecording = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)

    private var videoDrainThread: Thread? = null
    private var audioDrainThread: Thread? = null

    private var startTimeMs = 0L
    private var pauseStartTimeMs = 0L
    private var totalPausedDurationMs = 0L
    private var encodedBytes = 0L
    private var frameCount = 0L
    private var lastFpsCheckTime = 0L
    private var currentFps = 0

    @Throws(IOException::class)
    fun start() {
        Log.i(TAG, "Starting recording: ${width}x${height} @ ${settings.fps}fps, ${settings.bitrateMbps}Mbps, Codec=${settings.codec.name}")

        // 1. Initialize MediaMuxer
        mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // 2. Setup Video Encoder
        setupVideoEncoder()

        // 3. Setup Audio Encoder & Mixer
        if (settings.audioMode != AudioSourceMode.MUTED) {
            setupAudioEncoder()
        }

        // 4. Start Virtual Display
        virtualDisplay = mediaProjection.createVirtualDisplay(
            "ScreenRecorder-VD",
            width,
            height,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface,
            null,
            null
        )

        isRecording.set(true)
        isPaused.set(false)
        startTimeMs = System.currentTimeMillis()
        lastFpsCheckTime = startTimeMs

        // Start drain loops
        startVideoDrainLoop()
        if (settings.audioMode != AudioSourceMode.MUTED) {
            startAudioDrainLoop()
            audioMixer?.start()
        }
    }

    private fun setupVideoEncoder() {
        val mime = settings.codec.mimeType
        val format = MediaFormat.createVideoFormat(mime, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, settings.bitrateMbps * 1_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, settings.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second keyframe interval

            // Hardware Bitrate control
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            }
        }

        videoEncoder = MediaCodec.createEncoderByType(mime).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = createInputSurface()
            start()
        }
    }

    private fun setupAudioEncoder() {
        val audioMime = MediaFormat.MIMETYPE_AUDIO_AAC
        val sampleRate = 48000
        val channelCount = 2
        val audioBitrate = 192000

        val audioFormat = MediaFormat.createAudioFormat(audioMime, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, audioBitrate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        audioEncoder = MediaCodec.createEncoderByType(audioMime).apply {
            configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            start()
        }

        // Initialize Dual Audio Mixer
        audioMixer = DualAudioMixerEngine(
            audioMode = settings.audioMode,
            micGain = settings.micGain,
            systemGain = settings.systemGain,
            enableNoiseSuppression = settings.noiseSuppression,
            mediaProjection = mediaProjection,
            onMixedPcmReady = { buffer, size, ptsUs ->
                if (isRecording.get() && !isPaused.get()) {
                    feedAudioInput(buffer, size, ptsUs)
                }
            }
        )
    }

    private fun feedAudioInput(buffer: ByteArray, size: Int, ptsUs: Long) {
        val encoder = audioEncoder ?: return
        try {
            val inputIndex = encoder.dequeueInputBuffer(10_000)
            if (inputIndex >= 0) {
                val inputBuf = encoder.getInputBuffer(inputIndex)
                inputBuf?.clear()
                inputBuf?.put(buffer, 0, size)
                encoder.queueInputBuffer(inputIndex, 0, size, ptsUs, 0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error queuing audio buffer", e)
        }
    }

    private fun startVideoDrainLoop() {
        videoDrainThread = Thread({
            val bufferInfo = MediaCodec.BufferInfo()
            val encoder = videoEncoder ?: return@Thread

            while (isRecording.get()) {
                if (isPaused.get()) {
                    try { Thread.sleep(20) } catch (_: InterruptedException) { }
                    continue
                }

                try {
                    val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                    when (outputIndex) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            synchronized(isMuxerStarted) {
                                if (videoTrackIndex == -1) {
                                    videoTrackIndex = mediaMuxer?.addTrack(encoder.outputFormat) ?: -1
                                    Log.d(TAG, "Video track added: $videoTrackIndex")
                                    checkStartMuxer()
                                }
                            }
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // No output buffer available right now
                        }
                        else -> {
                            if (outputIndex >= 0) {
                                val encodedData = encoder.getOutputBuffer(outputIndex)
                                if (encodedData != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                    if (bufferInfo.size != 0 && isMuxerStarted.get()) {
                                        encodedData.position(bufferInfo.offset)
                                        encodedData.limit(bufferInfo.offset + bufferInfo.size)

                                        // Adjust timestamp for pauses
                                        val adjustedPts = bufferInfo.presentationTimeUs - (totalPausedDurationMs * 1000)
                                        bufferInfo.presentationTimeUs = maxOf(0L, adjustedPts)

                                        mediaMuxer?.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                                        encodedBytes += bufferInfo.size
                                        frameCount++

                                        updateMetrics()
                                    }
                                }
                                encoder.releaseOutputBuffer(outputIndex, false)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in video drain loop", e)
                    if (isRecording.get()) {
                        onError("Video encoding error: ${e.message}")
                    }
                    break
                }
            }
        }, "VideoDrainThread").apply { start() }
    }

    private fun startAudioDrainLoop() {
        audioDrainThread = Thread({
            val bufferInfo = MediaCodec.BufferInfo()
            val encoder = audioEncoder ?: return@Thread

            while (isRecording.get()) {
                if (isPaused.get()) {
                    try { Thread.sleep(20) } catch (_: InterruptedException) { }
                    continue
                }

                try {
                    val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                    when (outputIndex) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            synchronized(isMuxerStarted) {
                                if (audioTrackIndex == -1) {
                                    audioTrackIndex = mediaMuxer?.addTrack(encoder.outputFormat) ?: -1
                                    Log.d(TAG, "Audio track added: $audioTrackIndex")
                                    checkStartMuxer()
                                }
                            }
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> { }
                        else -> {
                            if (outputIndex >= 0) {
                                val encodedData = encoder.getOutputBuffer(outputIndex)
                                if (encodedData != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                    if (bufferInfo.size != 0 && isMuxerStarted.get()) {
                                        encodedData.position(bufferInfo.offset)
                                        encodedData.limit(bufferInfo.offset + bufferInfo.size)

                                        val adjustedPts = bufferInfo.presentationTimeUs - (totalPausedDurationMs * 1000)
                                        bufferInfo.presentationTimeUs = maxOf(0L, adjustedPts)

                                        mediaMuxer?.writeSampleData(audioTrackIndex, encodedData, bufferInfo)
                                        encodedBytes += bufferInfo.size
                                    }
                                }
                                encoder.releaseOutputBuffer(outputIndex, false)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in audio drain loop", e)
                    break
                }
            }
        }, "AudioDrainThread").apply { start() }
    }

    private fun checkStartMuxer() {
        val needsAudio = settings.audioMode != AudioSourceMode.MUTED
        val hasVideo = videoTrackIndex >= 0
        val hasAudio = !needsAudio || audioTrackIndex >= 0

        if (hasVideo && hasAudio && !isMuxerStarted.get()) {
            mediaMuxer?.start()
            isMuxerStarted.set(true)
            Log.i(TAG, "MediaMuxer started with videoTrack=$videoTrackIndex, audioTrack=$audioTrackIndex")
        }
    }

    private fun updateMetrics() {
        val now = System.currentTimeMillis()
        if (now - lastFpsCheckTime >= 1000) {
            val deltaSec = (now - lastFpsCheckTime) / 1000f
            currentFps = ((frameCount) / deltaSec).toInt().coerceAtMost(settings.fps)
            frameCount = 0
            lastFpsCheckTime = now

            val durationMs = if (isPaused.get()) {
                pauseStartTimeMs - startTimeMs - totalPausedDurationMs
            } else {
                now - startTimeMs - totalPausedDurationMs
            }
            onProgress(maxOf(0L, durationMs), encodedBytes, currentFps)
        }
    }

    fun pause() {
        if (isRecording.get() && !isPaused.get()) {
            isPaused.set(true)
            pauseStartTimeMs = System.currentTimeMillis()
            Log.d(TAG, "Recording paused")
        }
    }

    fun resume() {
        if (isRecording.get() && isPaused.get()) {
            val pauseDuration = System.currentTimeMillis() - pauseStartTimeMs
            totalPausedDurationMs += pauseDuration
            isPaused.set(false)
            Log.d(TAG, "Recording resumed, paused for $pauseDuration ms")
        }
    }

    fun stop() {
        Log.i(TAG, "Stopping screen recording...")
        isRecording.set(false)

        try {
            audioMixer?.stop()
        } catch (_: Exception) { }

        try {
            videoDrainThread?.interrupt()
            videoDrainThread?.join(500)
        } catch (_: Exception) { }

        try {
            audioDrainThread?.interrupt()
            audioDrainThread?.join(500)
        } catch (_: Exception) { }

        try {
            virtualDisplay?.release()
        } catch (_: Exception) { }
        virtualDisplay = null

        try {
            videoEncoder?.stop()
            videoEncoder?.release()
        } catch (_: Exception) { }
        videoEncoder = null

        try {
            audioEncoder?.stop()
            audioEncoder?.release()
        } catch (_: Exception) { }
        audioEncoder = null

        try {
            inputSurface?.release()
        } catch (_: Exception) { }
        inputSurface = null

        try {
            if (isMuxerStarted.get()) {
                mediaMuxer?.stop()
                mediaMuxer?.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing MediaMuxer", e)
        }
        mediaMuxer = null
        isMuxerStarted.set(false)

        Log.i(TAG, "Recording stopped successfully. File size: ${outputFile.length()} bytes")
    }
}
