package com.example.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.RecorderSettings
import com.example.data.RecordingEntity
import com.example.data.RecordingRepository
import com.example.overlay.FloatingControlService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class ScreenRecorderService : Service(), SensorEventListener {

    private val TAG = "ScreenRecorderService"
    private val NOTIFICATION_CHANNEL_ID = "screen_recorder_channel"
    private val NOTIFICATION_ID = 1001

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var recorder: MediaCodecRecorder? = null
    private var mediaProjection: MediaProjection? = null
    private var currentOutputFile: File? = null
    private var currentSettings: RecorderSettings = RecorderSettings()

    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var lastShakeTime = 0L

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_PAUSE = "ACTION_PAUSE"
        const val ACTION_RESUME = "ACTION_RESUME"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_SCREENSHOT = "ACTION_SCREENSHOT"

        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_DATA_INTENT = "EXTRA_DATA_INTENT"

        var activeMediaProjectionData: Intent? = null
        var activeResultCode: Int = 0

        private val _telemetry = MutableStateFlow(RecordingTelemetry())
        val telemetry: StateFlow<RecordingTelemetry> = _telemetry.asStateFlow()
    }

    inner class LocalBinder : Binder() {
        fun getService(): ScreenRecorderService = this@ScreenRecorderService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initShakeSensor()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Screen Recorder Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Live status and controls for active screen recording"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, ScreenRecorderService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val isPaused = _telemetry.value.status == RecordingStatus.PAUSED
        val toggleAction = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        val toggleTitle = if (isPaused) "Resume" else "Pause"
        val toggleIntent = Intent(this, ScreenRecorderService::class.java).apply { action = toggleAction }
        val togglePendingIntent = PendingIntent.getService(
            this, 2, toggleIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Screen Recorder Pro")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, toggleTitle, togglePendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }

                if (resultCode != 0 && data != null) {
                    activeResultCode = resultCode
                    activeMediaProjectionData = data
                    startRecordingInternal(resultCode, data)
                } else if (activeResultCode != 0 && activeMediaProjectionData != null) {
                    startRecordingInternal(activeResultCode, activeMediaProjectionData!!)
                }
            }
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
        }

        return START_NOT_STICKY
    }

    private fun startRecordingInternal(resultCode: Int, data: Intent) {
        val notification = buildNotification("Initializing recorder...")
        var fgsType = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                fgsType = fgsType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)

        serviceScope.launch {
            // Countdown if configured
            if (currentSettings.countdownSeconds > 0) {
                for (i in currentSettings.countdownSeconds downTo 1) {
                    _telemetry.value = _telemetry.value.copy(
                        status = RecordingStatus.COUNTDOWN,
                        countdownRemaining = i
                    )
                    delay(1000)
                }
            }

            try {
                val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjection = projectionManager.getMediaProjection(resultCode, data)

                // Get screen dimensions
                val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)

                val (targetWidth, targetHeight) = if (currentSettings.resolution.isNative) {
                    metrics.widthPixels to metrics.heightPixels
                } else {
                    // Adapt to screen orientation
                    if (metrics.widthPixels > metrics.heightPixels) {
                        currentSettings.resolution.width to currentSettings.resolution.height
                    } else {
                        currentSettings.resolution.height to currentSettings.resolution.width
                    }
                }

                // Ensure even dimensions for hardware encoder alignment (must be divisible by 16 or 2)
                val alignedWidth = (targetWidth / 2) * 2
                val alignedHeight = (targetHeight / 2) * 2

                // Setup output file in movies or app storage
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val storageDir = File(getExternalFilesDir(null), "Recordings").apply { mkdirs() }
                currentOutputFile = File(storageDir, "REC_${timeStamp}.${currentSettings.containerFormat.extension}")

                recorder = MediaCodecRecorder(
                    settings = currentSettings,
                    width = alignedWidth,
                    height = alignedHeight,
                    densityDpi = metrics.densityDpi,
                    mediaProjection = mediaProjection!!,
                    outputFile = currentOutputFile!!,
                    onProgress = { durationMs, bytes, fps ->
                        val durationSec = durationMs / 1000L
                        val hours = durationSec / 3600
                        val mins = (durationSec % 3600) / 60
                        val secs = durationSec % 60
                        val formatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, mins, secs)
                        val bitrateMbps = if (durationSec > 0) (bytes * 8.0 / (durationSec * 1_000_000)) else 0.0

                        _telemetry.value = _telemetry.value.copy(
                            status = if (_telemetry.value.status == RecordingStatus.PAUSED) RecordingStatus.PAUSED else RecordingStatus.RECORDING,
                            durationSeconds = durationSec,
                            formattedDuration = formatted,
                            activeBitrateMbps = bitrateMbps,
                            currentFps = fps,
                            recordedBytes = bytes,
                            countdownRemaining = 0
                        )

                        val notif = buildNotification("Recording: $formatted ($fps FPS, ${String.format(Locale.getDefault(), "%.1f", bitrateMbps)} Mbps)")
                        val notifManager = getSystemService(NotificationManager::class.java)
                        notifManager.notify(NOTIFICATION_ID, notif)
                    },
                    onError = { error ->
                        Log.e(TAG, "Recording error: $error")
                        _telemetry.value = _telemetry.value.copy(
                            status = RecordingStatus.ERROR,
                            errorMessage = error
                        )
                        stopRecording()
                    }
                )

                recorder?.start()
                _telemetry.value = _telemetry.value.copy(
                    status = RecordingStatus.RECORDING,
                    countdownRemaining = 0
                )

                // Launch floating overlay if enabled
                if (currentSettings.showFloatingControls) {
                    try {
                        val overlayIntent = Intent(this@ScreenRecorderService, FloatingControlService::class.java)
                        startService(overlayIntent)
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not start floating control service: ${e.message}")
                    }
                }

            } catch (e: Exception) {
                Log.e(TAG, "Failed to start recorder", e)
                _telemetry.value = _telemetry.value.copy(
                    status = RecordingStatus.ERROR,
                    errorMessage = e.message ?: "Unknown recording error"
                )
                stopRecording()
            }
        }
    }

    fun updateSettings(settings: RecorderSettings) {
        currentSettings = settings
    }

    private fun pauseRecording() {
        recorder?.pause()
        _telemetry.value = _telemetry.value.copy(status = RecordingStatus.PAUSED)
        val notif = buildNotification("Recording Paused (${_telemetry.value.formattedDuration})")
        val notifManager = getSystemService(NotificationManager::class.java)
        notifManager.notify(NOTIFICATION_ID, notif)
    }

    private fun resumeRecording() {
        recorder?.resume()
        _telemetry.value = _telemetry.value.copy(status = RecordingStatus.RECORDING)
        val notif = buildNotification("Recording: ${_telemetry.value.formattedDuration}")
        val notifManager = getSystemService(NotificationManager::class.java)
        notifManager.notify(NOTIFICATION_ID, notif)
    }

    private fun stopRecording() {
        if (_telemetry.value.status == RecordingStatus.IDLE || _telemetry.value.status == RecordingStatus.STOPPING) {
            return
        }

        _telemetry.value = _telemetry.value.copy(status = RecordingStatus.STOPPING)

        serviceScope.launch(Dispatchers.IO) {
            try {
                recorder?.stop()
                recorder = null
                mediaProjection?.stop()
                mediaProjection = null

                val savedFile = currentOutputFile
                if (savedFile != null && savedFile.exists() && savedFile.length() > 0) {
                    // Insert into Room DB
                    val db = AppDatabase.getDatabase(applicationContext)
                    val repo = RecordingRepository(db.recordingDao())
                    val durationMs = _telemetry.value.durationSeconds * 1000L

                    val entity = RecordingEntity(
                        title = savedFile.nameWithoutExtension,
                        filePath = savedFile.absolutePath,
                        durationMs = durationMs,
                        width = currentSettings.resolution.width,
                        height = currentSettings.resolution.height,
                        fps = currentSettings.fps,
                        bitrateMbps = currentSettings.bitrateMbps,
                        codec = currentSettings.codec.displayName,
                        containerFormat = currentSettings.containerFormat.displayName,
                        fileSize = savedFile.length(),
                        hasMicAudio = currentSettings.audioMode.name.contains("MIC") || currentSettings.audioMode.name.contains("DUAL"),
                        hasSystemAudio = currentSettings.audioMode.name.contains("SYSTEM") || currentSettings.audioMode.name.contains("DUAL"),
                        hasFacecam = currentSettings.showFacecam
                    )
                    repo.insert(entity)

                    _telemetry.value = _telemetry.value.copy(
                        status = RecordingStatus.IDLE,
                        lastSavedFilePath = savedFile.absolutePath,
                        durationSeconds = 0,
                        formattedDuration = "00:00:00",
                        activeBitrateMbps = 0.0,
                        currentFps = 0
                    )
                } else {
                    _telemetry.value = _telemetry.value.copy(status = RecordingStatus.IDLE)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error finalizing recording", e)
                _telemetry.value = _telemetry.value.copy(status = RecordingStatus.IDLE)
            }

            // Stop Floating Overlay
            try {
                val overlayIntent = Intent(this@ScreenRecorderService, FloatingControlService::class.java)
                stopService(overlayIntent)
            } catch (_: Exception) { }

            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun initShakeSensor() {
        try {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            accelerometer?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        } catch (_: Exception) { }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER && currentSettings.shakeToStop) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            val gForce = sqrt((x * x + y * y + z * z).toDouble()) / SensorManager.GRAVITY_EARTH

            if (gForce > 2.7) { // Shake detected
                val now = System.currentTimeMillis()
                if (now - lastShakeTime > 2000) {
                    lastShakeTime = now
                    if (_telemetry.value.status == RecordingStatus.RECORDING || _telemetry.value.status == RecordingStatus.PAUSED) {
                        Log.i(TAG, "Shake gesture detected! Stopping recording.")
                        stopRecording()
                    }
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager?.unregisterListener(this)
        recorder?.stop()
        mediaProjection?.stop()
    }
}
