package com.example.engine

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import com.example.data.AudioSourceMode
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

class DualAudioMixerEngine(
    private val audioMode: AudioSourceMode,
    private val micGain: Float = 1.0f,
    private val systemGain: Float = 1.0f,
    private val enableNoiseSuppression: Boolean = true,
    private val mediaProjection: MediaProjection? = null,
    private val onMixedPcmReady: (ByteArray, Int, Long) -> Unit
) {
    private val TAG = "DualAudioMixerEngine"

    val sampleRate = 48000
    val channelConfig = AudioFormat.CHANNEL_IN_STEREO
    val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private var micRecord: AudioRecord? = null
    private var systemRecord: AudioRecord? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null

    @Volatile
    private var isRecording = false
    private var workerThread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (audioMode == AudioSourceMode.MUTED) {
            Log.d(TAG, "Audio is muted; not starting audio mixer.")
            return
        }

        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBufferSize * 2, 8192)

        // Setup Mic Capture
        if (audioMode == AudioSourceMode.DUAL || audioMode == AudioSourceMode.MIC_ONLY) {
            try {
                micRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                if (micRecord?.state == AudioRecord.STATE_INITIALIZED) {
                    val sessionId = micRecord?.audioSessionId ?: 0
                    if (sessionId != 0 && enableNoiseSuppression) {
                        if (NoiseSuppressor.isAvailable()) {
                            noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
                        }
                        if (AcousticEchoCanceler.isAvailable()) {
                            echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
                        }
                    }
                    micRecord?.startRecording()
                } else {
                    Log.w(TAG, "Mic AudioRecord failed to initialize")
                    micRecord = null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing Mic capture", e)
            }
        }

        // Setup System Audio Playback Capture (API 29+)
        if ((audioMode == AudioSourceMode.DUAL || audioMode == AudioSourceMode.SYSTEM_ONLY) &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null
        ) {
            try {
                val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()

                val audioFormatObj = AudioFormat.Builder()
                    .setEncoding(audioFormat)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()

                systemRecord = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(playbackConfig)
                    .setAudioFormat(audioFormatObj)
                    .setBufferSizeInBytes(bufferSize)
                    .build()

                if (systemRecord?.state == AudioRecord.STATE_INITIALIZED) {
                    systemRecord?.startRecording()
                } else {
                    Log.w(TAG, "System AudioRecord failed to initialize")
                    systemRecord = null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing System Audio capture", e)
            }
        }

        isRecording = true
        startMixingLoop(bufferSize)
    }

    private fun startMixingLoop(chunkSize: Int) {
        workerThread = Thread({
            val micBuffer = ByteArray(chunkSize)
            val sysBuffer = ByteArray(chunkSize)
            val mixedBuffer = ByteArray(chunkSize)

            while (isRecording) {
                var micBytesRead = 0
                var sysBytesRead = 0

                micRecord?.let {
                    micBytesRead = it.read(micBuffer, 0, chunkSize)
                }

                systemRecord?.let {
                    sysBytesRead = it.read(sysBuffer, 0, chunkSize)
                }

                val bytesToProcess = max(max(0, micBytesRead), max(0, sysBytesRead))
                if (bytesToProcess <= 0) {
                    try {
                        Thread.sleep(10)
                    } catch (_: InterruptedException) { }
                    continue
                }

                // Mix 16-bit PCM buffers with gain
                mixPcmBuffers(
                    micBuffer = micBuffer,
                    micBytes = max(0, micBytesRead),
                    micGain = micGain,
                    sysBuffer = sysBuffer,
                    sysBytes = max(0, sysBytesRead),
                    sysGain = systemGain,
                    outputBuffer = mixedBuffer,
                    targetBytes = bytesToProcess
                )

                val presentationTimeUs = System.nanoTime() / 1000L
                onMixedPcmReady(mixedBuffer, bytesToProcess, presentationTimeUs)
            }
        }, "DualAudioMixerThread").apply { start() }
    }

    private fun mixPcmBuffers(
        micBuffer: ByteArray,
        micBytes: Int,
        micGain: Float,
        sysBuffer: ByteArray,
        sysBytes: Int,
        sysGain: Float,
        outputBuffer: ByteArray,
        targetBytes: Int
    ) {
        val numSamples = targetBytes / 2
        val micShorts = ByteBuffer.wrap(micBuffer, 0, micBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val sysShorts = ByteBuffer.wrap(sysBuffer, 0, sysBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val outShorts = ByteBuffer.wrap(outputBuffer, 0, targetBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()

        for (i in 0 until numSamples) {
            val micSample = if (i < micBytes / 2) (micShorts.get(i) * micGain) else 0f
            val sysSample = if (i < sysBytes / 2) (sysShorts.get(i) * sysGain) else 0f

            // Soft-clip summing to avoid harsh distortion
            val sum = micSample + sysSample
            val clamped = when {
                sum > Short.MAX_VALUE -> Short.MAX_VALUE.toFloat()
                sum < Short.MIN_VALUE -> Short.MIN_VALUE.toFloat()
                else -> sum
            }
            outShorts.put(i, clamped.toInt().toShort())
        }
    }

    fun stop() {
        isRecording = false
        try {
            workerThread?.interrupt()
            workerThread?.join(500)
        } catch (_: Exception) { }
        workerThread = null

        try {
            micRecord?.stop()
            micRecord?.release()
        } catch (_: Exception) { }
        micRecord = null

        try {
            systemRecord?.stop()
            systemRecord?.release()
        } catch (_: Exception) { }
        systemRecord = null

        try {
            noiseSuppressor?.release()
            echoCanceler?.release()
        } catch (_: Exception) { }
        noiseSuppressor = null
        echoCanceler = null
    }
}
