package com.example.engine

enum class RecordingStatus {
    IDLE,
    COUNTDOWN,
    RECORDING,
    PAUSED,
    STOPPING,
    ERROR
}

data class RecordingTelemetry(
    val status: RecordingStatus = RecordingStatus.IDLE,
    val durationSeconds: Long = 0L,
    val formattedDuration: String = "00:00:00",
    val activeBitrateMbps: Double = 0.0,
    val currentFps: Int = 0,
    val recordedBytes: Long = 0L,
    val droppedFrames: Long = 0L,
    val countdownRemaining: Int = 0,
    val lastSavedFilePath: String? = null,
    val errorMessage: String? = null
)
