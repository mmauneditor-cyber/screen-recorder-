package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.overlay.AnnotationCanvasOverlay
import com.example.overlay.FacecamOverlayView
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioDashboardScreen
import com.example.ui.screens.VideoPlayerDialog
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.theme.StudioCrimson
import com.example.ui.viewmodel.RecorderViewModel

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Studio : Screen("studio", "Studio", Icons.Default.Videocam)
    object Gallery : Screen("gallery", "Recordings", Icons.Default.Collections)
    object Settings : Screen("settings", "Settings", Icons.Default.Tune)
}

@Composable
fun ScreenRecorderApp(
    viewModel: RecorderViewModel,
    onRequestMediaProjection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val items = listOf(Screen.Studio, Screen.Gallery, Screen.Settings)
    val isAnnotationActive by viewModel.isAnnotationActive.collectAsState()
    val activePlayback by viewModel.activePlaybackRecording.collectAsState()
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Slate950,
        bottomBar = {
            NavigationBar(
                containerColor = Slate900,
                tonalElevation = 8.dp
            ) {
                items.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = isSelected,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = StudioCrimson,
                            selectedTextColor = StudioCrimson,
                            indicatorColor = Slate800,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_${screen.route}"),
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Studio.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Studio.route) {
                    StudioDashboardScreen(
                        viewModel = viewModel,
                        onRequestMediaProjection = onRequestMediaProjection,
                        onNavigateToSettings = {
                            navController.navigate(Screen.Settings.route)
                        }
                    )
                }
                composable(Screen.Gallery.route) {
                    GalleryScreen(viewModel = viewModel)
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(viewModel = viewModel)
                }
            }

            // In-app Facecam preview overlay
            if (settings.showFacecam) {
                FacecamOverlayView(
                    shape = settings.facecamShape,
                    sizeDp = settings.facecamSizeDp,
                    onClose = { viewModel.toggleFacecam(false) }
                )
            }

            // Real-time On-Screen Annotation Drawing layer
            AnimatedVisibility(
                visible = isAnnotationActive,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                AnnotationCanvasOverlay(
                    onClose = { viewModel.toggleAnnotations(false) }
                )
            }

            // Video Player Dialog
            activePlayback?.let { recording ->
                VideoPlayerDialog(
                    recording = recording,
                    onDismiss = { viewModel.selectForPlayback(null) }
                )
            }
        }
    }
}
