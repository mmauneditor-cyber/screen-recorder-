package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AudioSourceMode
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun AudioGainMixerCard(
    audioMode: AudioSourceMode,
    micGain: Float,
    systemGain: Float,
    noiseSuppression: Boolean,
    onMicGainChange: (Float) -> Unit,
    onSystemGainChange: (Float) -> Unit,
    onNoiseSuppressionChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        shape = RoundedCornerShape(20.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Slate800))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.SurroundSound,
                        contentDescription = "Audio Mixer",
                        tint = StudioCyan
                    )
                    Text(
                        text = "DUAL AUDIO MIXER & GAIN",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Slate200
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate800
                ) {
                    Text(
                        text = if (audioMode == AudioSourceMode.DUAL) "MIC + SYSTEM" else audioMode.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioEmerald,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // External Microphone Gain Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = "Mic",
                            tint = StudioCrimson,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "External Microphone Input",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate300
                        )
                    }
                    Text(
                        text = "${(micGain * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = StudioCrimson
                    )
                }

                Slider(
                    value = micGain,
                    onValueChange = onMicGainChange,
                    valueRange = 0.0f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioCrimson,
                        activeTrackColor = StudioCrimson,
                        inactiveTrackColor = Slate800
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Internal System Audio Gain Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.VolumeUp,
                            contentDescription = "System Audio",
                            tint = StudioCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Internal System Audio Capture",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate300
                        )
                    }
                    Text(
                        text = "${(systemGain * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = StudioCyan
                    )
                }

                Slider(
                    value = systemGain,
                    onValueChange = onSystemGainChange,
                    valueRange = 0.0f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioCyan,
                        activeTrackColor = StudioCyan,
                        inactiveTrackColor = Slate800
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Noise Suppression Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate950, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hardware Noise Suppression",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate200,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Suppresses background hum and keyboard typing noise",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                }
                Switch(
                    checked = noiseSuppression,
                    onCheckedChange = onNoiseSuppressionChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = StudioEmerald,
                        checkedTrackColor = StudioEmerald.copy(alpha = 0.3f),
                        uncheckedTrackColor = Slate800
                    )
                )
            }
        }
    }
}
