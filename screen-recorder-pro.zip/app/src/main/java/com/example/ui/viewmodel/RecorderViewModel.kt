package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class RecorderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RecordingRepository

    val telemetry: StateFlow<RecordingTelemetry> = ScreenRecorderService.telemetry

    private val _settings = MutableStateFlow(RecorderSettings())
    val settings: StateFlow<RecorderSettings> = _settings.asStateFlow()

    private val _selectedProfile = MutableStateFlow(DEFAULT_STUDIO_PROFILES[1]) // 1080p FHD default
    val selectedProfile: StateFlow<StudioProfile> = _selectedProfile.asStateFlow()

    val recordings: StateFlow<List<RecordingEntity>>
    val totalStorageBytes: StateFlow<Long?>

    val hardwareEncoders: List<CodecCapability> = HardwareCodecDetector.getSupportedEncoders()

    private val _activePlaybackRecording = MutableStateFlow<RecordingEntity?>(null)
    val activePlaybackRecording: StateFlow<RecordingEntity?> = _activePlaybackRecording.asStateFlow()

    private val _isAnnotationActive = MutableStateFlow(false)
    val isAnnotationActive: StateFlow<Boolean> = _isAnnotationActive.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = RecordingRepository(db.recordingDao())

        recordings = repository.allRecordings.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        totalStorageBytes = repository.totalStorageBytes.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )
    }

    fun applyProfile(profile: StudioProfile) {
        _selectedProfile.value = profile
        _settings.update {
            it.copy(
                resolution = profile.resolution,
                fps = profile.fps,
                bitrateMbps = profile.bitrateMbps,
                codec = profile.codec,
                audioMode = profile.audioMode
            )
        }
    }

    fun updateResolution(resolution: ResolutionPreset) {
        _settings.update { it.copy(resolution = resolution) }
    }

    fun updateFps(fps: Int) {
        _settings.update { it.copy(fps = fps) }
    }

    fun updateBitrate(mbps: Int) {
        _settings.update { it.copy(bitrateMbps = mbps) }
    }

    fun updateCodec(codec: VideoCodec) {
        _settings.update { it.copy(codec = codec) }
    }

    fun updateContainer(container: ContainerFormat) {
        _settings.update { it.copy(containerFormat = container) }
    }

    fun updateAudioMode(mode: AudioSourceMode) {
        _settings.update { it.copy(audioMode = mode) }
    }

    fun updateMicGain(gain: Float) {
        _settings.update { it.copy(micGain = gain) }
    }

    fun updateSystemGain(gain: Float) {
        _settings.update { it.copy(systemGain = gain) }
    }

    fun toggleNoiseSuppression(enabled: Boolean) {
        _settings.update { it.copy(noiseSuppression = enabled) }
    }

    fun toggleFloatingControls(show: Boolean) {
        _settings.update { it.copy(showFloatingControls = show) }
    }

    fun toggleFacecam(show: Boolean) {
        _settings.update { it.copy(showFacecam = show) }
    }

    fun updateFacecamShape(shape: FacecamShape) {
        _settings.update { it.copy(facecamShape = shape) }
    }

    fun updateFacecamSize(sizeDp: Int) {
        _settings.update { it.copy(facecamSizeDp = sizeDp) }
    }

    fun updateCountdown(seconds: Int) {
        _settings.update { it.copy(countdownSeconds = seconds) }
    }

    fun toggleShakeToStop(enabled: Boolean) {
        _settings.update { it.copy(shakeToStop = enabled) }
    }

    fun toggleAnnotations(active: Boolean) {
        _isAnnotationActive.value = active
    }

    fun startRecording(resultCode: Int, data: Intent) {
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_START
            putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenRecorderService.EXTRA_DATA_INTENT, data)
        }
        context.startService(serviceIntent)
    }

    fun pauseRecording() {
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_PAUSE
        }
        context.startService(serviceIntent)
    }

    fun resumeRecording() {
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_RESUME
        }
        context.startService(serviceIntent)
    }

    fun stopRecording() {
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_STOP
        }
        context.startService(serviceIntent)
    }

    fun selectForPlayback(recording: RecordingEntity?) {
        _activePlaybackRecording.value = recording
    }

    fun deleteRecording(recording: RecordingEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(recording)
        }
    }

    fun toggleFavorite(recording: RecordingEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleFavorite(recording)
        }
    }

    fun renameRecording(id: Long, newTitle: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.rename(id, newTitle)
        }
    }
}
