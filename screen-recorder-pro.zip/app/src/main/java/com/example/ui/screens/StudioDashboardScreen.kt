package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DEFAULT_STUDIO_PROFILES
import com.example.data.FacecamShape
import com.example.engine.RecordingStatus
import com.example.ui.components.AudioGainMixerCard
import com.example.ui.components.LiveTelemetryCard
import com.example.ui.components.StudioProfileCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.RecorderViewModel

enum class CaptureRegionMode(val title: String) {
    FULL_SCREEN("Full Screen"),
    REGIONAL("Regional Crop"),
    WINDOW_FOCUS("App Focus")
}

@Composable
fun StudioDashboardScreen(
    viewModel: RecorderViewModel,
    onRequestMediaProjection: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val telemetry by viewModel.telemetry.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val selectedProfile by viewModel.selectedProfile.collectAsState()

    var captureRegion by remember { mutableStateOf(CaptureRegionMode.FULL_SCREEN) }
    var showOverlayPermissionDialog by remember { mutableStateOf(false) }

    val isRecording = telemetry.status == RecordingStatus.RECORDING
    val isPaused = telemetry.status == RecordingStatus.PAUSED
    val isBusy = isRecording || isPaused || telemetry.status == RecordingStatus.COUNTDOWN || telemetry.status == RecordingStatus.STOPPING

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Studio Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MEDIA STUDIO",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCrimson,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Screen Recorder Pro",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            IconButton(
                onClick = onNavigateToSettings,
                modifier = Modifier
                    .size(44.dp)
                    .background(Slate900, CircleShape)
                    .border(1.dp, Slate800, CircleShape)
            ) {
                Icon(
                    Icons.Default.Tune,
                    contentDescription = "Studio Settings",
                    tint = Slate200
                )
            }
        }

        // Live Telemetry Card
        LiveTelemetryCard(telemetry = telemetry)

        // Capture Mode Segmented Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Slate900
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                for (mode in CaptureRegionMode.entries) {
                    val isSelected = captureRegion == mode
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp)),
                        color = if (isSelected) Slate800 else Color.Transparent,
                        onClick = { captureRegion = mode }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Slate400
                            )
                        }
                    }
                }
            }
        }

        // Regional Capture Indicator Guide
        if (captureRegion == CaptureRegionMode.REGIONAL) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Slate900,
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(StudioCyan.copy(alpha = 0.5f))
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Crop,
                        contentDescription = "Regional Indicator",
                        tint = StudioCyan
                    )
                    Column {
                        Text(
                            text = "Regional Cropping Active (16:9)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate200
                        )
                        Text(
                            text = "Capture boundaries will be locked to the center window frame during recording.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate400
                        )
                    }
                }
            }
        }

        // Primary Action Controls (Record / Pause / Resume / Stop)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Slate900),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isRecording && !isPaused) {
                    // Start Recording Master Button
                    Button(
                        onClick = onRequestMediaProjection,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("start_recording_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudioCrimson,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            Icons.Default.RadioButtonChecked,
                            contentDescription = "Start Recording",
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "START RECORDING",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                } else {
                    // Pause / Resume Button
                    OutlinedButton(
                        onClick = {
                            if (isPaused) viewModel.resumeRecording() else viewModel.pauseRecording()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isPaused) StudioEmerald else RecordingAmber
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(
                                if (isPaused) StudioEmerald else RecordingAmber
                            )
                        )
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = if (isPaused) "Resume" else "Pause"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isPaused) "RESUME" else "PAUSE",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Stop Button
                    Button(
                        onClick = { viewModel.stopRecording() },
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("stop_recording_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudioCrimson,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            Icons.Default.Stop,
                            contentDescription = "Stop Recording"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "STOP",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Live Tool Quick Toggles (Facecam, Annotations, Floating Bar)
        Text(
            text = "LIVE STUDIO TOOLS",
            style = MaterialTheme.typography.labelSmall,
            color = Slate400,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Facecam Toggle Chip
            FilterChip(
                selected = settings.showFacecam,
                onClick = { viewModel.toggleFacecam(!settings.showFacecam) },
                label = { Text("Facecam") },
                leadingIcon = {
                    Icon(
                        Icons.Default.Face,
                        contentDescription = "Facecam",
                        tint = if (settings.showFacecam) StudioCrimson else Slate400
                    )
                },
                modifier = Modifier.weight(1f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Slate800,
                    selectedLabelColor = Color.White
                )
            )

            // On-screen Annotations Toggle Chip
            FilterChip(
                selected = viewModel.isAnnotationActive.collectAsState().value,
                onClick = {
                    viewModel.toggleAnnotations(!viewModel.isAnnotationActive.value)
                },
                label = { Text("Annotate") },
                leadingIcon = {
                    Icon(
                        Icons.Default.Draw,
                        contentDescription = "Draw Overlay",
                        tint = if (viewModel.isAnnotationActive.collectAsState().value) StudioCyan else Slate400
                    )
                },
                modifier = Modifier.weight(1f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Slate800,
                    selectedLabelColor = Color.White
                )
            )

            // Floating Controls Bar
            FilterChip(
                selected = settings.showFloatingControls,
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                        showOverlayPermissionDialog = true
                    } else {
                        viewModel.toggleFloatingControls(!settings.showFloatingControls)
                    }
                },
                label = { Text("Floating Bar") },
                leadingIcon = {
                    Icon(
                        Icons.Default.Layers,
                        contentDescription = "Floating Controls",
                        tint = if (settings.showFloatingControls) StudioEmerald else Slate400
                    )
                },
                modifier = Modifier.weight(1.2f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Slate800,
                    selectedLabelColor = Color.White
                )
            )
        }

        // Facecam Controls Expanded Sub-bar
        if (settings.showFacecam) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Slate900
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Facecam Mask Shape",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate300
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.facecamShape == FacecamShape.CIRCLE,
                            onClick = { viewModel.updateFacecamShape(FacecamShape.CIRCLE) },
                            label = { Text("Circle") }
                        )
                        FilterChip(
                            selected = settings.facecamShape == FacecamShape.ROUNDED_RECT,
                            onClick = { viewModel.updateFacecamShape(FacecamShape.ROUNDED_RECT) },
                            label = { Text("Rounded") }
                        )
                    }
                }
            }
        }

        // Studio Profiles Horizontal Carousel
        Column {
            Text(
                text = "STUDIO RECORDING PRESETS",
                style = MaterialTheme.typography.labelSmall,
                color = Slate400,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (profile in DEFAULT_STUDIO_PROFILES) {
                    StudioProfileCard(
                        profile = profile,
                        isSelected = selectedProfile.id == profile.id,
                        onSelect = { viewModel.applyProfile(profile) }
                    )
                }
            }
        }

        // Dual Audio Gain Mixer Card
        AudioGainMixerCard(
            audioMode = settings.audioMode,
            micGain = settings.micGain,
            systemGain = settings.systemGain,
            noiseSuppression = settings.noiseSuppression,
            onMicGainChange = { viewModel.updateMicGain(it) },
            onSystemGainChange = { viewModel.updateSystemGain(it) },
            onNoiseSuppressionChange = { viewModel.toggleNoiseSuppression(it) }
        )

        // Hardware Acceleration Telemetry Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Slate900
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    Icons.Default.Memory,
                    contentDescription = "Hardware Acceleration",
                    tint = StudioEmerald
                )
                Column {
                    Text(
                        text = "Hardware MediaCodec Pipeline Active",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate200
                    )
                    Text(
                        text = "Direct Surface input encoding enabled with zero memory copying and native 60 FPS acceleration.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400
                    )
                }
            }
        }
    }

    // Permission Dialog for Floating Overlays
    if (showOverlayPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showOverlayPermissionDialog = false },
            title = { Text("Display Over Other Apps") },
            text = {
                Text("To display the floating controller bar and facecam overlay while using other apps, please grant the 'Draw over other apps' permission.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOverlayPermissionDialog = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCrimson)
                ) {
                    Text("Open Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOverlayPermissionDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
