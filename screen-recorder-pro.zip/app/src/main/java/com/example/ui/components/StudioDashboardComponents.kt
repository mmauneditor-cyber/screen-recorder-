package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StudioProfile
import com.example.engine.RecordingStatus
import com.example.engine.RecordingTelemetry
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun LiveTelemetryCard(
    telemetry: RecordingTelemetry,
    modifier: Modifier = Modifier
) {
    val isRecording = telemetry.status == RecordingStatus.RECORDING
    val isPaused = telemetry.status == RecordingStatus.PAUSED
    val isCountdown = telemetry.status == RecordingStatus.COUNTDOWN

    // Pulsing animation for the recording indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        shape = RoundedCornerShape(24.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(
                    if (isRecording) StudioCrimson else Slate700,
                    if (isPaused) RecordingAmber else Slate800
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isRecording -> StudioCrimson.copy(alpha = pulseAlpha)
                                    isPaused -> RecordingAmber
                                    isCountdown -> StudioCyan
                                    else -> Slate600
                                }
                            )
                    )
                    Text(
                        text = when {
                            isRecording -> "LIVE CAPTURE ACTIVE"
                            isPaused -> "RECORDING PAUSED"
                            isCountdown -> "STARTING IN ${telemetry.countdownRemaining}s..."
                            else -> "STUDIO READY"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            isRecording -> StudioCrimson
                            isPaused -> RecordingAmber
                            isCountdown -> StudioCyan
                            else -> Slate400
                        },
                        letterSpacing = 1.2.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate800
                ) {
                    Text(
                        text = "HARDWARE ENCODER",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Time Ticker Display
            Text(
                text = telemetry.formattedDuration,
                fontFamily = FontFamily.Monospace,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                color = if (isRecording) Color.White else Slate200,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Real-Time Telemetry Gauges: FPS, Bitrate, Storage Size
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate950, RoundedCornerShape(16.dp))
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TelemetryMetricItem(
                    label = "FRAME RATE",
                    value = if (isRecording) "${telemetry.currentFps} FPS" else "60 FPS",
                    color = StudioEmerald
                )
                Box(
                    modifier = Modifier
                        .height(32.dp)
                        .width(1.dp)
                        .background(Slate800)
                )
                TelemetryMetricItem(
                    label = "REAL-TIME BITRATE",
                    value = if (isRecording) String.format(Locale.getDefault(), "%.1f Mbps", telemetry.activeBitrateMbps) else "-- Mbps",
                    color = StudioCyan
                )
                Box(
                    modifier = Modifier
                        .height(32.dp)
                        .width(1.dp)
                        .background(Slate800)
                )
                TelemetryMetricItem(
                    label = "RECORDED SIZE",
                    value = formatBytes(telemetry.recordedBytes),
                    color = RecordingAmber
                )
            }
        }
    }
}

@Composable
fun TelemetryMetricItem(
    label: String,
    value: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Slate400,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun StudioProfileCard(
    profile: StudioProfile,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(220.dp)
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Slate800 else Slate900
        ),
        shape = RoundedCornerShape(16.dp),
        border = if (isSelected) {
            CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(StudioCrimson, StudioCyan)))
        } else {
            CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Slate800, Slate800)))
        }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = profile.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) StudioCrimson else Slate200
                )
                if (isSelected) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = StudioCrimson,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = profile.description,
                style = MaterialTheme.typography.bodySmall,
                color = Slate400,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Slate950
                ) {
                    Text(
                        text = "${profile.resolution.name} • ${profile.fps}fps",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyan,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Slate950
                ) {
                    Text(
                        text = "${profile.bitrateMbps}M",
                        style = MaterialTheme.typography.labelSmall,
                        color = RecordingAmber,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0.0 MB"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024.0) {
        String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
    } else {
        String.format(Locale.getDefault(), "%.1f MB", mb)
    }
}
