package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Dark Theme Palette
val Slate950 = Color(0xFF090D16)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)

// Accents
val StudioCrimson = Color(0xFFEF4444)
val StudioCrimsonDark = Color(0xFFB91C1C)
val StudioCrimsonLight = Color(0xFFFCA5A5)

val RecordingAmber = Color(0xFFF59E0B)
val StudioEmerald = Color(0xFF10B981)
val StudioCyan = Color(0xFF06B6D4)
val StudioViolet = Color(0xFF8B5CF6)

val CardBackgroundDark = Color(0xFF131C2E)
val SurfaceContainerHighestDark = Color(0xFF1E293B)
