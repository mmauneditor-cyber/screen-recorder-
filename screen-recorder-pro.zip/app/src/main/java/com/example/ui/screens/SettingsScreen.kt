package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RecorderViewModel

@Composable
fun SettingsScreen(
    viewModel: RecorderViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val hardwareCodecs = viewModel.hardwareEncoders

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Settings Header
        Column {
            Text(
                text = "ENGINE SPECIFICATIONS & CONFIGURATION",
                style = MaterialTheme.typography.labelSmall,
                color = StudioCrimson,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Studio Settings",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Section: Video Specifications
        SettingsSection(title = "VIDEO ENCODER & RESOLUTION", icon = Icons.Default.VideoSettings) {
            // Resolution Selection
            Text(
                text = "Capture Resolution",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (preset in STANDARD_RESOLUTIONS) {
                    val isSelected = settings.resolution.name == preset.name
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Slate800 else Slate950,
                        border = if (isSelected) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioCrimson)) else null,
                        onClick = { viewModel.updateResolution(preset) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = preset.displayLabel,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isSelected) Color.White else Slate300,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = StudioCrimson, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Frame Rate
            Text(
                text = "Frame Rate (FPS)",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val fpsOptions = listOf(24, 30, 60, 120)
                for (fps in fpsOptions) {
                    val isSelected = settings.fps == fps
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) StudioCrimson else Slate950,
                        onClick = { viewModel.updateFps(fps) }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$fps FPS",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Slate400
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Codec Selection: H.264 vs HEVC
            Text(
                text = "Hardware Compression Codec",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (codec in VideoCodec.entries) {
                    val isSelected = settings.codec == codec
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Slate800 else Slate950,
                        border = if (isSelected) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioCyan)) else null,
                        onClick = { viewModel.updateCodec(codec) }
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (codec == VideoCodec.H264) "H.264 / AVC" else "HEVC / H.265",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) StudioCyan else Slate300
                            )
                            Text(
                                text = if (codec == VideoCodec.H264) "Broad Compatibility" else "High Efficiency",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate400
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bitrate Slider (Up to 100 Mbps)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Encoding Bitrate",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate200,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${settings.bitrateMbps} Mbps (Up to 100 Mbps)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = RecordingAmber,
                    fontFamily = FontFamily.Monospace
                )
            }
            Slider(
                value = settings.bitrateMbps.toFloat(),
                onValueChange = { viewModel.updateBitrate(it.toInt()) },
                valueRange = 4f..100f,
                steps = 95,
                colors = SliderDefaults.colors(
                    thumbColor = RecordingAmber,
                    activeTrackColor = RecordingAmber,
                    inactiveTrackColor = Slate950
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Container Format: MP4 vs MKV
            Text(
                text = "Container Format",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (fmt in ContainerFormat.entries) {
                    val isSelected = settings.containerFormat == fmt
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Slate800 else Slate950,
                        border = if (isSelected) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioEmerald)) else null,
                        onClick = { viewModel.updateContainer(fmt) }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = fmt.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) StudioEmerald else Slate400
                            )
                        }
                    }
                }
            }
        }

        // Section: Dual Audio Capture
        SettingsSection(title = "AUDIO ENGINE & ROUTING", icon = Icons.Default.Audiotrack) {
            Text(
                text = "Audio Capture Channel",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (mode in AudioSourceMode.entries) {
                    val isSelected = settings.audioMode == mode
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Slate800 else Slate950,
                        border = if (isSelected) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioCyan)) else null,
                        onClick = { viewModel.updateAudioMode(mode) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mode.displayName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isSelected) Color.White else Slate300,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = StudioCyan, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Section: Controls & Gestures
        SettingsSection(title = "HOTKEYS & GESTURE CONTROLS", icon = Icons.Default.Gesture) {
            // Shake to Stop
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Shake Device to Stop",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate200
                    )
                    Text(
                        text = "Vigorously shake device to terminate recording without opening controls",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400
                    )
                }
                Switch(
                    checked = settings.shakeToStop,
                    onCheckedChange = { viewModel.toggleShakeToStop(it) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Countdown Timer
            Text(
                text = "Pre-Recording Countdown",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate200,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val countdowns = listOf(0, 3, 5, 10)
                for (cd in countdowns) {
                    val isSelected = settings.countdownSeconds == cd
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) StudioCrimson else Slate950,
                        onClick = { viewModel.updateCountdown(cd) }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (cd == 0) "None" else "${cd}s",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Slate400
                            )
                        }
                    }
                }
            }
        }

        // Section: Hardware Encoders Telemetry
        SettingsSection(title = "HARDWARE CODEC TELEMETRY", icon = Icons.Default.Memory) {
            if (hardwareCodecs.isEmpty()) {
                Text(
                    text = "Probing system hardware video encoders...",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate400
                )
            } else {
                for (codec in hardwareCodecs) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Slate950
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = codec.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (codec.isHardwareAccelerated) StudioEmerald.copy(alpha = 0.2f) else Slate800
                                ) {
                                    Text(
                                        text = if (codec.isHardwareAccelerated) "HARDWARE NVENC/HW" else "SOFTWARE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (codec.isHardwareAccelerated) StudioEmerald else Slate400,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Vendor: ${codec.vendor} • Max: ${codec.maxWidth}x${codec.maxHeight} @ ${codec.maxFps}fps, ${codec.maxBitrateMbps} Mbps",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate400
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Section: Senior Media Architect Tech Stack Recommendation
        SettingsSection(title = "TECH STACK & ARCHITECTURE ANALYSIS", icon = Icons.Default.Architecture) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Recommended Tech Stack: Native Android MediaProjection + MediaCodec",
                    style = MaterialTheme.typography.titleSmall,
                    color = StudioEmerald,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "1. Zero-Copy Hardware Pipeline: MediaProjection directly pipes screen frames to a Surface allocated by MediaCodec. This bypasses CPU and RAM bottlenecks, maintaining 60 FPS up to 4K resolution.\n" +
                            "2. Dual Audio Capture: AudioPlaybackCapture (API 29+) captures internal system audio without loopback hardware, while AudioRecord captures the mic simultaneously with noise suppression.\n" +
                            "3. Why Not Electron / Flutter?: Electron runs with heavy Chromium overhead (~300MB RAM), while Flutter requires FFI marshalling for high-rate frame buffers, introducing latency. Native Kotlin + Jetpack Compose offers lowest CPU utilization and true background persistence.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate300,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        shape = RoundedCornerShape(20.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Slate800))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(icon, contentDescription = title, tint = StudioCrimson, modifier = Modifier.size(20.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Slate200,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}
