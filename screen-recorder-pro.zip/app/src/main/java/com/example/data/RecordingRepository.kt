package com.example.data

import kotlinx.coroutines.flow.Flow
import java.io.File

class RecordingRepository(private val recordingDao: RecordingDao) {

    val allRecordings: Flow<List<RecordingEntity>> = recordingDao.getAllRecordings()
    val totalCount: Flow<Int> = recordingDao.getRecordingsCount()
    val totalStorageBytes: Flow<Long?> = recordingDao.getTotalStorageUsed()

    suspend fun insert(recording: RecordingEntity): Long {
        return recordingDao.insertRecording(recording)
    }

    suspend fun getById(id: Long): RecordingEntity? {
        return recordingDao.getRecordingById(id)
    }

    suspend fun delete(recording: RecordingEntity) {
        // Delete disk file
        try {
            val file = File(recording.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) { }
        recordingDao.deleteRecordingById(recording.id)
    }

    suspend fun toggleFavorite(recording: RecordingEntity) {
        recordingDao.setFavorite(recording.id, !recording.isFavorite)
    }

    suspend fun rename(id: Long, newTitle: String) {
        recordingDao.renameRecording(id, newTitle)
    }
}
