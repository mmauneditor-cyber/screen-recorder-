package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrateMbps: Int,
    val codec: String,
    val containerFormat: String,
    val fileSize: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val hasMicAudio: Boolean,
    val hasSystemAudio: Boolean,
    val hasFacecam: Boolean,
    val isFavorite: Boolean = false,
    val notes: String = ""
)
