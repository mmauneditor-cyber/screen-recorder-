package com.example.data

enum class VideoCodec(val displayName: String, val mimeType: String) {
    H264("H.264 (AVC) - High Compatibility", "video/avc"),
    HEVC("HEVC (H.265) - Maximum Efficiency", "video/hevc")
}

enum class ContainerFormat(val extension: String, val displayName: String) {
    MP4("mp4", "MPEG-4 (.mp4)"),
    MKV("mkv", "Matroska (.mkv)")
}

enum class AudioSourceMode(val displayName: String) {
    DUAL("Dual Audio (Internal System + Microphone)"),
    SYSTEM_ONLY("Internal System Audio Only"),
    MIC_ONLY("External Microphone Only"),
    MUTED("Muted (No Audio)")
}

enum class FacecamShape(val displayName: String) {
    CIRCLE("Circular Aperture"),
    ROUNDED_RECT("Rounded Rectangle")
}

data class ResolutionPreset(
    val name: String,
    val width: Int,
    val height: Int,
    val isNative: Boolean = false
) {
    val displayLabel: String
        get() = if (isNative) "$name (Native Screen)" else "$name (${width}x${height})"
}

val STANDARD_RESOLUTIONS = listOf(
    ResolutionPreset("4K UHD", 3840, 2160),
    ResolutionPreset("2K QHD", 2560, 1440),
    ResolutionPreset("1080p FHD", 1920, 1080),
    ResolutionPreset("720p HD", 1280, 720),
    ResolutionPreset("Native Display", 0, 0, isNative = true)
)

data class StudioProfile(
    val id: String,
    val name: String,
    val description: String,
    val resolution: ResolutionPreset,
    val fps: Int,
    val bitrateMbps: Int,
    val codec: VideoCodec,
    val audioMode: AudioSourceMode
)

val DEFAULT_STUDIO_PROFILES = listOf(
    StudioProfile(
        id = "4k_master",
        name = "4K UHD Master",
        description = "Ultra-crisp 4K 60FPS at 80 Mbps HEVC for pristine professional mastering",
        resolution = STANDARD_RESOLUTIONS[0],
        fps = 60,
        bitrateMbps = 80,
        codec = VideoCodec.HEVC,
        audioMode = AudioSourceMode.DUAL
    ),
    StudioProfile(
        id = "1080p_pro",
        name = "1080p FHD 60FPS",
        description = "Broadcast standard 60 FPS at 25 Mbps H.264 for YouTube & streaming",
        resolution = STANDARD_RESOLUTIONS[2],
        fps = 60,
        bitrateMbps = 25,
        codec = VideoCodec.H264,
        audioMode = AudioSourceMode.DUAL
    ),
    StudioProfile(
        id = "gameplay_high",
        name = "Gaming High Refresh",
        description = "Smooth 60 FPS with hardware HEVC acceleration & zero frame drop",
        resolution = STANDARD_RESOLUTIONS[4], // Native
        fps = 60,
        bitrateMbps = 35,
        codec = VideoCodec.HEVC,
        audioMode = AudioSourceMode.DUAL
    ),
    StudioProfile(
        id = "tutorial_facecam",
        name = "Tutorial & Demo",
        description = "Optimized for speech, presentations and facecam overlay",
        resolution = STANDARD_RESOLUTIONS[2],
        fps = 30,
        bitrateMbps = 15,
        codec = VideoCodec.H264,
        audioMode = AudioSourceMode.MIC_ONLY
    )
)

data class RecorderSettings(
    val resolution: ResolutionPreset = STANDARD_RESOLUTIONS[2], // 1080p default
    val fps: Int = 60,
    val bitrateMbps: Int = 25,
    val codec: VideoCodec = VideoCodec.H264,
    val containerFormat: ContainerFormat = ContainerFormat.MP4,
    val audioMode: AudioSourceMode = AudioSourceMode.DUAL,
    val micGain: Float = 1.0f,
    val systemGain: Float = 1.0f,
    val noiseSuppression: Boolean = true,
    val showFloatingControls: Boolean = true,
    val autoHideFloatingBar: Boolean = false,
    val showFacecam: Boolean = false,
    val facecamShape: FacecamShape = FacecamShape.CIRCLE,
    val facecamSizeDp: Int = 140,
    val countdownSeconds: Int = 3,
    val shakeToStop: Boolean = true,
    val showTouches: Boolean = true
)
