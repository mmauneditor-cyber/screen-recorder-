package com.example.overlay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

enum class AnnotationTool {
    PEN,
    ARROW,
    RECTANGLE,
    LASER
}

data class DrawnElement(
    val tool: AnnotationTool,
    val points: List<Offset>,
    val color: Color,
    val strokeWidth: Float
)

@Composable
fun AnnotationCanvasOverlay(
    modifier: Modifier = Modifier,
    onClose: () -> Unit
) {
    var currentTool by remember { mutableStateOf(AnnotationTool.PEN) }
    var currentColor by remember { mutableStateOf(StudioCrimson) }
    var strokeWidth by remember { mutableFloatStateOf(8f) }

    val elements = remember { mutableStateListOf<DrawnElement>() }
    var currentPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var laserPoint by remember { mutableStateOf<Offset?>(null) }

    val colors = listOf(StudioCrimson, RecordingAmber, StudioEmerald, StudioCyan, Color.White)

    Box(modifier = modifier.fillMaxSize()) {
        // Transparent Drawing Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(currentTool, currentColor, strokeWidth) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            if (currentTool == AnnotationTool.LASER) {
                                laserPoint = offset
                            } else {
                                currentPoints = listOf(offset)
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (currentTool == AnnotationTool.LASER) {
                                laserPoint = change.position
                            } else {
                                currentPoints = currentPoints + change.position
                            }
                        },
                        onDragEnd = {
                            if (currentTool == AnnotationTool.LASER) {
                                laserPoint = null
                            } else if (currentPoints.isNotEmpty()) {
                                elements.add(
                                    DrawnElement(
                                        tool = currentTool,
                                        points = currentPoints,
                                        color = currentColor,
                                        strokeWidth = strokeWidth
                                    )
                                )
                                currentPoints = emptyList()
                            }
                        }
                    )
                }
        ) {
            // Draw finalized elements
            for (element in elements) {
                drawElement(element)
            }

            // Draw current active element in progress
            if (currentPoints.isNotEmpty()) {
                drawElement(
                    DrawnElement(
                        tool = currentTool,
                        points = currentPoints,
                        color = currentColor,
                        strokeWidth = strokeWidth
                    )
                )
            }

            // Draw laser pointer glowing dot
            laserPoint?.let { pos ->
                drawCircle(
                    color = StudioCrimson.copy(alpha = 0.3f),
                    radius = 32f,
                    center = pos
                )
                drawCircle(
                    color = StudioCrimson,
                    radius = 14f,
                    center = pos
                )
                drawCircle(
                    color = Color.White,
                    radius = 6f,
                    center = pos
                )
            }
        }

        // Top Control Tool Ribbon
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp, start = 12.dp, end = 12.dp),
            color = Slate900.copy(alpha = 0.92f),
            shape = RoundedCornerShape(24.dp),
            tonalElevation = 8.dp,
            shadowElevation = 10.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Tool Selectors
                IconButton(
                    onClick = { currentTool = AnnotationTool.PEN },
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = if (currentTool == AnnotationTool.PEN) StudioCrimson else Slate400
                    )
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Pen Tool")
                }

                IconButton(
                    onClick = { currentTool = AnnotationTool.ARROW },
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = if (currentTool == AnnotationTool.ARROW) StudioCrimson else Slate400
                    )
                ) {
                    Icon(Icons.Default.TrendingFlat, contentDescription = "Arrow Tool")
                }

                IconButton(
                    onClick = { currentTool = AnnotationTool.RECTANGLE },
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = if (currentTool == AnnotationTool.RECTANGLE) StudioCrimson else Slate400
                    )
                ) {
                    Icon(Icons.Default.CropSquare, contentDescription = "Rectangle Tool")
                }

                IconButton(
                    onClick = { currentTool = AnnotationTool.LASER },
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = if (currentTool == AnnotationTool.LASER) StudioCrimson else Slate400
                    )
                ) {
                    Icon(Icons.Default.Highlight, contentDescription = "Laser Highlight")
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .height(24.dp)
                        .width(1.dp)
                        .background(Slate700)
                )

                // Color choices
                for (color in colors) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(color, CircleShape)
                            .border(
                                width = if (currentColor == color) 2.dp else 0.dp,
                                color = if (currentColor == color) Color.White else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { currentColor = color }
                    )
                }

                Box(
                    modifier = Modifier
                        .height(24.dp)
                        .width(1.dp)
                        .background(Slate700)
                )

                // Undo
                IconButton(
                    onClick = { if (elements.isNotEmpty()) elements.removeLast() },
                    enabled = elements.isNotEmpty()
                ) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo")
                }

                // Clear All
                IconButton(
                    onClick = { elements.clear() },
                    enabled = elements.isNotEmpty()
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All")
                }

                // Close Overlay
                IconButton(
                    onClick = onClose,
                    colors = IconButtonDefaults.iconButtonColors(contentColor = StudioCrimson)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Annotations")
                }
            }
        }
    }
}

private fun DrawScope.drawElement(element: DrawnElement) {
    val pts = element.points
    if (pts.isEmpty()) return

    when (element.tool) {
        AnnotationTool.PEN -> {
            if (pts.size == 1) {
                drawCircle(color = element.color, radius = element.strokeWidth / 2, center = pts[0])
            } else {
                val path = Path().apply {
                    moveTo(pts[0].x, pts[0].y)
                    for (i in 1 until pts.size) {
                        lineTo(pts[i].x, pts[i].y)
                    }
                }
                drawPath(
                    path = path,
                    color = element.color,
                    style = Stroke(
                        width = element.strokeWidth,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
        AnnotationTool.RECTANGLE -> {
            val start = pts.first()
            val end = pts.last()
            val left = minOf(start.x, end.x)
            val top = minOf(start.y, end.y)
            val right = maxOf(start.x, end.x)
            val bottom = maxOf(start.y, end.y)
            drawRect(
                color = element.color,
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(right - left, bottom - top),
                style = Stroke(width = element.strokeWidth)
            )
        }
        AnnotationTool.ARROW -> {
            val start = pts.first()
            val end = pts.last()
            drawLine(
                color = element.color,
                start = start,
                end = end,
                strokeWidth = element.strokeWidth,
                cap = StrokeCap.Round
            )
            // Arrowhead
            val angle = atan2(end.y - start.y, end.x - start.x)
            val arrowLength = 36f
            val arrowAngle = Math.PI / 6.0
            val p1 = Offset(
                (end.x - arrowLength * cos(angle - arrowAngle)).toFloat(),
                (end.y - arrowLength * sin(angle - arrowAngle)).toFloat()
            )
            val p2 = Offset(
                (end.x - arrowLength * cos(angle + arrowAngle)).toFloat(),
                (end.y - arrowLength * sin(angle + arrowAngle)).toFloat()
            )
            drawLine(color = element.color, start = end, end = p1, strokeWidth = element.strokeWidth, cap = StrokeCap.Round)
            drawLine(color = element.color, start = end, end = p2, strokeWidth = element.strokeWidth, cap = StrokeCap.Round)
        }
        AnnotationTool.LASER -> {
            // Handled separately
        }
    }
}
