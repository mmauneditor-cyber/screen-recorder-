package com.example.overlay

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.engine.RecordingStatus
import com.example.engine.ScreenRecorderService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingControlService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private var isExpanded = true

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 200
        }

        floatingView = createFloatingPillView(params)
        try {
            windowManager?.addView(floatingView, params)
        } catch (_: Exception) { }

        observeRecorderTelemetry()
    }

    private fun createFloatingPillView(params: WindowManager.LayoutParams): View {
        val root = FrameLayout(this)

        val pillLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xDD0F172A.toInt()) // Sleek semi-translucent dark slate
            gravity = Gravity.CENTER_VERTICAL
        }

        // Live status dot
        val dot = ImageView(this).apply {
            setImageResource(android.R.drawable.presence_online)
            setColorFilter(0xFFEF4444.toInt()) // Red recording dot
            setPadding(0, 0, 16, 0)
        }
        pillLayout.addView(dot)

        // Timer text
        val timerText = TextView(this).apply {
            text = "00:00:00"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setPadding(0, 0, 20, 0)
        }
        pillLayout.addView(timerText)

        // Pause/Resume Button
        val pauseBtn = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_pause)
            setBackgroundColor(0x00000000)
            setColorFilter(0xFFF59E0B.toInt()) // Amber
            setPadding(12, 12, 12, 12)
            setOnClickListener {
                val isPaused = ScreenRecorderService.telemetry.value.status == RecordingStatus.PAUSED
                val action = if (isPaused) ScreenRecorderService.ACTION_RESUME else ScreenRecorderService.ACTION_PAUSE
                val intent = Intent(this@FloatingControlService, ScreenRecorderService::class.java).apply {
                    this.action = action
                }
                startService(intent)
            }
        }
        pillLayout.addView(pauseBtn)

        // Stop Button
        val stopBtn = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(0x00000000)
            setColorFilter(0xFFEF4444.toInt()) // Crimson
            setPadding(12, 12, 12, 12)
            setOnClickListener {
                val intent = Intent(this@FloatingControlService, ScreenRecorderService::class.java).apply {
                    action = ScreenRecorderService.ACTION_STOP
                }
                startService(intent)
            }
        }
        pillLayout.addView(stopBtn)

        // Open Studio Button
        val openAppBtn = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_preferences)
            setBackgroundColor(0x00000000)
            setColorFilter(0xFF06B6D4.toInt()) // Cyan
            setPadding(12, 12, 12, 12)
            setOnClickListener {
                val intent = Intent(this@FloatingControlService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }
        pillLayout.addView(openAppBtn)

        root.addView(pillLayout)

        // Touch listener for dragging the floating bar
        pillLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return false // let click listeners work if not moved
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            params.x = initialX + dx
                            params.y = initialY + dy
                            windowManager?.updateViewLayout(root, params)
                            return true
                        }
                    }
                }
                return false
            }
        })

        return root
    }

    private fun observeRecorderTelemetry() {
        scope.launch {
            ScreenRecorderService.telemetry.collectLatest { tele ->
                if (tele.status == RecordingStatus.IDLE) {
                    stopSelf()
                } else {
                    // Update timer text if view is available
                    val timerView = floatingView?.findViewWithTag<TextView>("timer")
                        ?: (floatingView as? FrameLayout)?.getChildAt(0)?.let {
                            if (it is LinearLayout && it.childCount > 1) it.getChildAt(1) as? TextView else null
                        }
                    timerView?.text = tele.formattedDuration
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        if (floatingView != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (_: Exception) { }
            floatingView = null
        }
    }
}
